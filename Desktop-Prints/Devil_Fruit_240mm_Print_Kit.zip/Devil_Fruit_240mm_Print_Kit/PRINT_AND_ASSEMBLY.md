# Red Pixel Devil Fruit — 240 mm print kit

A square-grid reconstruction of the supplied reference: red fruit, connected black spirals and outline, and a white curled stem. Pixel edges remain square. The trace regularizes the perspective-distorted reference and connects corner-touching spiral strokes so the black overlay is a single printable solid.

**Finished size: 213.33 W × 240 H × 9.60 D mm (8.40 × 9.45 × 0.38 in).**

Open `START_HERE.html` for all views and downloads. Use the four files in `STL` for separate single-color printing. `Devil_Fruit_240mm_Assembly.3mf` is a colored, aligned geometry assembly, not a printer-profile project. It contains four named parts; STL files are unitless, so import them as millimetres at 100% scale. Each STL is already flat, face-up, with its lowest face at Z=0.

## Parts — print one of each

| File | Filament | Print envelope, mm | Purpose |
|---|---|---|---|
| 01_black_backing.stl | Black | 213.33 × 240 × 9.40 | Flat 4.8 mm rear web, 2.4 mm raised rim, and three upward alignment keys |
| 02_red_fruit.stl | Red | 199.50 × 172.83 × 2.40 | One solid fruit insert; no separate red pixels |
| 03_black_spiral_overlay.stl | Black | 213.33 × 240 × 2.40 | One connected outline-and-spiral layer with three key sockets |
| 04_white_curled_stem.stl | White | 146.17 × 66.17 × 4.80 | Stem insert; lower 2.4 mm seats in the backing, upper 2.4 mm reaches the outline face |

Black is split into a backing and an overlay to make support-free, single-color printing practical. No AMS or mid-print filament changes are required. Your Creality Hyper PLA black and Soyelin Ultra PLA red can provide those colors; white PLA is needed for the stem.

## Printing

The four STLs were individually sliced using the installed Bambu Studio 02.08.02.61, Bambu Lab P1S 0.4 nozzle profile, 0.20 mm layers, 3 walls, 4 top/bottom layers, 10% gyroid infill, supports disabled, and no brim. Use the same starting settings, then apply your calibrated filament temperature/flow settings. Print parts separately so each color is a single job. Keep the supplied face-up orientation.

The largest parts were successfully arranged at X=21.33, Y=8.00 on the P1S plate with its exclusion zone retained. Leave scale at 100%; do not automatically shrink to fit. A broad brim was not used in the verified layout.

Generic PLA slicing estimates: backing 118 g / 3 h 7 min; red 62 g / 1 h 33 min; black overlay 47 g / 1 h 45 min; stem 9 g / 24 min. Total approximately **237 g and 6 h 49 min**, excluding assembly. These are slicer estimates, not measured print results. Ordinary infill bridges occur inside the backing; the exterior geometry requires no supports.

## Assembly

1. Let the parts cool flat. Remove any brim, strings, or first-layer flare from mating edges.
2. Dry-fit the red body in the large shaped backing recess. Dry-fit the white stem in its own recess, then remove it temporarily.
3. Test the black overlay on the backing's three square keys. The overlay rests on the red body and backing rim. It should seat gently, without forcing the thin spiral network.
4. Remove the overlay. Apply a thin layer or small dots of PLA-compatible adhesive to the red insert's underside and seat it. Avoid thick glue beads that change the layer height.
5. Glue the black overlay to the red body and rim, lowering it over the three keys. Keep it level until cured. The key ends intentionally stop 0.2 mm below the black face.
6. Glue the white stem into its shaped opening. Its top should be flush with the black outline. Keep glue away from visible edges.

The keys and shaped pockets provide alignment, **not a snap fit**. Nominal pocket clearance is 0.25 mm per side (0.50 mm overall); square keys are 3.8 mm across and their through-sockets are 4.3 mm. Printer calibration and first-layer expansion still affect the fit. Dry-fit before gluing; lightly dress an edge if necessary.

## Layer stack and features

- Rear web: Z=0–4.8 mm, completely flat at the wall.
- Red body and backing rim: Z=4.8–7.2 mm.
- Black outline and spirals: Z=7.2–9.6 mm, raised 2.4 mm above the red face.
- White stem: Z=4.8–9.6 mm, with the lower half recessed.
- Pixel pitch: 6.667 mm; narrow white strokes are at least 6.167 mm after clearance. The small key/socket walls are approximately 1.18 mm at their thinnest.

The front intentionally uses shallow relief, like the reference. No plaque, rectangular base, frame, lettering, hook, gradients, or surface textures are part of the printable geometry.

## Wall mounting

The fruit's rear web provides a large uninterrupted flat mounting surface. Place Command strips or strong double-sided mounting tape on the broad rear fruit body; distribute them across the upper and lower body. Follow the adhesive manufacturer's surface preparation, load, and removal instructions. No protruding hook is included. The model has a flat back; the adhesive itself determines the final wall gap.

## Verification

Every STL was exported, reloaded, and checked for watertightness, consistently oriented faces, positive volume, two faces per edge, connected vertex links, one connected solid, and correct dimensions. All pairwise assembly intersection volumes are zero. The 3MF was independently reloaded, checked as four meshes, and imported by Bambu Studio, which reports `manifold = yes`, `number_of_parts = 4`, and 213.33 × 240 × 9.60 mm. Each STL sliced successfully without plate warnings, support toolpaths, or filament changes.

These are digital mesh and slicer checks. The kit has not been physically test-printed or load-tested. Full evidence is in `mesh_verification.json` and `verification/`.

## Views and editable files

- `01_front_concept.png` and `.svg`: flat reference-traced artwork.
- `02_front_orthographic.png`: front view of actual printable solids.
- `03_rear_orthographic.png`: rear view, naturally mirrored relative to the front.
- `04_side_profile.png`: true right-side silhouette, showing the total thickness. The black perimeter hides the internal colors from this exact angle.
- `05_exploded_assembly.png`: separated parts, with separation exaggerated for clarity.
- `06_assembled_render.png`: assembled perspective view.
- `Devil_Fruit_240mm.blend`: editable exact mesh assembly at metre scale, with millimetre display units.
- `source/`: reproducible Python model and render source. In that directory, install `requirements.txt`, run `python build_print.py`, then run Blender in background with `--python render_views.py`. Generated results appear in its `output/` directory.

[Higgsfield interactive preview](https://higgsfield.ai/3d-jutsu/052c26fc-94c0-4883-bd9c-52381b8d8b78) uses editable polygon extrusions. Use the local STLs/3MF as the verified printing masters.

Format reference: [3MF Consortium Core Specification](https://github.com/3MFConsortium/spec_core/blob/master/3MF%20Core%20Specification.md). Printer envelope reference: [Bambu Lab P1S](https://us.store.bambulab.com/collections/3d-printer/products/p1s).
