import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Matrix

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output'
parts=json.loads((OUT/'assembly_geometry.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='MILLIMETERS'
objects={}
for name,p in parts.items():
    mesh=bpy.data.meshes.new(name);mesh.from_pydata([[v/1000 for v in co] for co in p['vertices']],[],p['faces']);mesh.update()
    obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj);objects[name]=obj
    color=tuple(int(p['color'][i:i+2],16)/255 for i in [1,3,5])
    # Workbench material diffuse values are linear.
    color=tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in color)
    mat=bpy.data.materials.new(name+'_color');mat.diffuse_color=(*color,1)
    mat.use_nodes=True;mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(*color,1)
    mat.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.85
    obj.data.materials.append(mat)
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='Delivery camera';scene.camera=cam
cam.data.type='ORTHO';cam.data.clip_start=.001;cam.data.clip_end=100
scene.render.engine='BLENDER_WORKBENCH'
scene.render.resolution_x=1400;scene.render.resolution_y=1500;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.world.color=(.8,.8,.8)
s=scene.display.shading;s.light='FLAT';s.color_type='MATERIAL';s.show_shadows=False;s.show_cavity=False;s.show_object_outline=False
s.background_type='WORLD';s.show_specular_highlight=False
scene.view_settings.view_transform='Standard'
scene.view_settings.look='None'
scene.view_settings.exposure=0;scene.view_settings.gamma=1
def shot(name,pos,target,scale,flat=True):
    cam.location=pos
    backward=(cam.location-Vector(target)).normalized()
    right=Vector((0,1,0)).cross(backward).normalized();up=backward.cross(right)
    cam.rotation_euler=Matrix((right,up,backward)).transposed().to_euler()
    bpy.context.view_layer.update()
    points=[cam.matrix_world.inverted() @ (o.matrix_world @ v.co) for o in objects.values() for v in o.data.vertices]
    lo=[min(p[i] for p in points) for i in [0,1]];hi=[max(p[i] for p in points) for i in [0,1]]
    cam.location+=right*((lo[0]+hi[0])/2)+up*((lo[1]+hi[1])/2)
    cam.data.ortho_scale=max(hi[1]-lo[1],(hi[0]-lo[0])/(scene.render.resolution_x/scene.render.resolution_y))*1.16
    s.light='FLAT' if flat else 'STUDIO';s.show_shadows=False;s.show_cavity=not flat
    if not flat:s.cavity_type='WORLD';s.curvature_ridge_factor=1.2;s.curvature_valley_factor=1
    scene.render.filepath=str(OUT/name);bpy.ops.render.render(write_still=True)

shot('02_front_orthographic.png',(.106667,.120,1),(.106667,.120,0),.282)
shot('03_rear_orthographic.png',(.106667,.120,-1),(.106667,.120,0),.282)
shot('04_side_profile.png',(1,.120,.0048),(.106667,.120,.0048),.282)
shot('06_assembled_render.png',(.42,-.32,.9),(.106667,.12,.005),.295,False)
# Keep an editable assembled scene on disk.
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'Devil_Fruit_240mm.blend'))
objects['02_red_fruit'].location.z=.036
objects['04_white_curled_stem'].location.z=.071
objects['03_black_spiral_overlay'].location.z=.108
shot('05_exploded_assembly.png',(.55,-.48,.62),(.106667,.12,.055),.350,False)
print('Rendered all five engineering views.')
