"""Reference-traced pixel sprite. Coordinates are pixels; dimensions are millimetres."""
import numpy as np
from scipy.ndimage import binary_dilation, label
from PIL import Image, ImageDraw
from pathlib import Path
from shapely.geometry import box
from shapely.ops import unary_union

PIXEL=240/36
PALETTE={'black':'#111111','red':'#d51226','white':'#f5f5f2'}
ROWS=Path(__file__).with_name('trace_grid.txt').read_text().splitlines()
red=np.array([[v=='R' for v in row] for row in ROWS])
white=np.array([[v=='W' for v in row] for row in ROWS])
# Regularize the perspective-distorted reference onto square cells.
white[:]=False
for y,a,b in [(1,22,26),(2,19,23),(2,26,27),(3,17,20),(3,27,27),
              (4,15,18),(4,24,24),(4,27,27),(5,6,8),(5,12,17),
              (5,23,24),(5,26,27),(6,7,15),(6,24,26),
              (7,8,12),(7,14,15),(8,14,15),(9,14,15),(10,14,15)]:
    white[y,a:b+1]=True
# Remove photographic edge noise, keeping the same six main curl locations.
for y,x in [(11,9),(12,20),(13,15),(16,22),(20,12),(24,2),(25,8),(26,21)]:
    red[y,x]=False
for y,a,b in [(10,10,12),(11,10,13),(11,15,16),(12,11,14),
              (13,11,13),(13,16,19),(16,23,25),(18,1,3),
              (19,2,2),(20,29,29),(21,28,28),(22,28,28),
              (23,28,28),(24,28,28),(25,0,5),(28,21,24),
              (33,10,14),(34,10,18)]:
    red[y,a:b+1]=True
extents={9:(18,19),10:(10,21),11:(8,23),12:(7,25),13:(6,26),
14:(4,27),15:(3,27),16:(2,28),17:(1,28),18:(1,29),19:(0,29),
20:(0,29),21:(0,29),22:(0,29),23:(0,29),24:(0,29),25:(0,28),
26:(1,28),27:(2,27),28:(2,26),29:(3,25),30:(4,24),31:(6,23),
32:(7,22),33:(9,20),34:(10,18)}
body=np.zeros_like(red)
for y,(a,b) in extents.items(): body[y,a:b+1]=True
red &= body & ~white
white=np.pad(white,1);red=np.pad(red,1);body=np.pad(body,1)
structure=np.ones((3,3),bool)
silhouette=binary_dilation(body|white,structure=structure)
black=silhouette & ~red & ~white
# A cap must be one physically connected part, with no isolated specks.
# Remove only tiny raster artifacts. Join larger curl strokes at their nearest
# corner so the full black design remains one flat, robust printable part.
from collections import deque
labs,n=label(black);sizes=np.bincount(labs.ravel());sizes[0]=0
for k in range(1,n+1):
    if sizes[k]<=2: red[labs==k]=True
black=silhouette & ~red & ~white
while True:
    labs,n=label(black)
    if n==1:break
    sizes=np.bincount(labs.ravel());sizes[0]=0;main=sizes.argmax()
    start=[tuple(v) for v in np.argwhere(labs==main)]
    q=deque(start); prev={v:None for v in start};end=None
    while q and end is None:
        p=q.popleft()
        for dy,dx in [(0,1),(1,0),(0,-1),(-1,0)]:
            v=(p[0]+dy,p[1]+dx)
            if not(0<=v[0]<37 and 0<=v[1]<32) or v in prev:continue
            if not silhouette[v] or white[v]:continue
            prev[v]=p
            if black[v] and labs[v]!=main:end=v;break
            q.append(v)
    if end is None:raise RuntimeError('Cannot connect cap')
    while end is not None:
        red[end]=False;black[end]=True;end=prev[end]
black=silhouette & ~red & ~white

# Resolve diagonal-only corner contacts before extrusion. A 2x2 checkerboard
# would become a nonmanifold vertical edge even though its 2D polygon is valid.
changed=True
while changed:
    changed=False
    for y in range(36):
        for x in range(31):
            q=black[y:y+2,x:x+2]
            if q.sum()==2 and q[0,0]==q[1,1] and q[0,1]==q[1,0]:
                choices=[(y+dy,x+dx) for dy,dx in [(0,0),(0,1),(1,0),(1,1)] if red[y+dy,x+dx]]
                if choices:
                    v=choices[0];red[v]=False;black[v]=True;changed=True

def poly(mask):
    h=mask.shape[0]
    return unary_union([box(x*PIXEL,(h-y-1)*PIXEL,(x+1)*PIXEL,(h-y)*PIXEL)
                        for y,x in zip(*np.where(mask))]).simplify(1e-7)

def concept():
    out=Path('output');out.mkdir(exist_ok=True)
    unit=28; im=Image.new('RGB',(32*unit,37*unit),'#eae8e2');d=ImageDraw.Draw(im)
    for mask,c in [(silhouette,'black'),(red,'red'),(white,'white')]:
        for y,x in zip(*np.where(mask)):
            d.rectangle((int(x*unit),int(y*unit),int((x+1)*unit-1),int((y+1)*unit-1)),fill=PALETTE[c])
    im.save(out/'01_front_concept.png')
    svg=['<svg xmlns="http://www.w3.org/2000/svg" width="213.333mm" height="240mm" viewBox="0 1 32 36">']
    for mask,c in [(silhouette,'black'),(red,'red'),(white,'white')]:
        for y,x in zip(*np.where(mask)):
            svg.append(f'<rect x="{x}" y="{y}" width="1" height="1" fill="{PALETTE[c]}"/>')
    svg.append('</svg>');(out/'01_front_concept.svg').write_text('\n'.join(svg))
    for name,m in [('silhouette',silhouette),('body',body),('white',white),('cap',black)]:
        p=poly(m);print(name,p.geom_type,p.is_valid,p.area)

if __name__=='__main__':concept()
