"""Build exact printable solids from the reference-traced square grid.
Run: .venv/Scripts/python.exe build_print.py
No image-to-mesh approximation: every face is a plane, and all dimensions are mm.
"""
import json, zipfile, hashlib
from pathlib import Path
import numpy as np
import trimesh
from shapely.geometry import box
from shapely.ops import unary_union
from xml.etree.ElementTree import Element, SubElement, tostring
from design import poly, silhouette, body, white, black, red, PIXEL, concept

OUT=Path('output'); STL=OUT/'STL';STL.mkdir(parents=True,exist_ok=True)
BASE=4.8; LAYER=2.4; CLEARANCE=.25
shape=poly(silhouette)
stem=poly(white)
fruit=poly(body).difference(stem)
rim=shape.difference(fruit.union(stem))
cap=poly(black)

def ext(p,z,h):
    if p.geom_type=='MultiPolygon':
        return trimesh.util.concatenate([ext(q,z,h) for q in p.geoms])
    m=trimesh.creation.extrude_polygon(p,h,engine='earcut')
    m.apply_translation([0,0,z]);return m

def union(meshes):return trimesh.boolean.union(meshes,engine='manifold')

# Choose three widely spaced square locating keys entirely inside the solid rim.
candidates=[]
for y,x in zip(*np.where(silhouette)):
    cx=(x+.5)*PIXEL;cy=(37-y-.5)*PIXEL
    if rim.contains(box(cx-2.35,cy-2.35,cx+2.35,cy+2.35)):
        candidates.append((cx,cy))
targets=[(15,100),(190,70),(160,230)]
keys=[]
for tx,ty in targets:
    p=min(candidates,key=lambda p:(p[0]-tx)**2+(p[1]-ty)**2)
    keys.append(p)
key_polys=[box(x-1.9,y-1.9,x+1.9,y+1.9) for x,y in keys]
key_sockets=[box(x-2.15,y-2.15,x+2.15,y+2.15) for x,y in keys]
cap=cap.difference(unary_union(key_sockets))
red_insert=fruit.buffer(-CLEARANCE,join_style=2)
white_insert=stem.buffer(-CLEARANCE,join_style=2)
assert red_insert.geom_type==white_insert.geom_type==cap.geom_type=='Polygon'

parts={
'01_black_backing':union([ext(shape,0,BASE),ext(rim,BASE,LAYER)]+[ext(p,BASE+LAYER,2.2) for p in key_polys]),
'02_red_fruit':ext(red_insert,BASE,LAYER),
'03_black_spiral_overlay':ext(cap,BASE+LAYER,LAYER),
'04_white_curled_stem':ext(white_insert,BASE,2*LAYER),
}
colors={'01_black_backing':'#111111','02_red_fruit':'#D51226','03_black_spiral_overlay':'#111111','04_white_curled_stem':'#F5F5F2'}
report={'units':'millimeter','pixel_pitch_mm':PIXEL,'base_web_mm':BASE,
        'visible_detail_layer_mm':LAYER,'per_side_clearance_mm':CLEARANCE,
        'key_width_mm':3.8,'socket_width_mm':4.3,'key_height_mm':2.2,
        'key_centers_xy_mm':keys,'parts':{},'intersections_mm3':{}}

def verify(m,name):
    assert m.is_watertight, f'{name}: open mesh'
    assert m.is_winding_consistent, f'{name}: winding'
    assert m.is_volume and m.volume>0, f'{name}: not positive volume'
    assert len(m.split())==1, f'{name}: disconnected shells'
    counts=np.bincount(m.edges_unique_inverse)
    assert np.all(counts==2),f'{name}: nonmanifold edge'
    assert np.isfinite(m.vertices).all()
    # Each vertex link is one connected cycle: also detects point singularities.
    for v in range(len(m.vertices)):
        fs=m.faces[np.any(m.faces==v,axis=1)]
        edges=[list(f[f!=v]) for f in fs]; adj={}
        for a,b in edges:adj.setdefault(int(a),set()).add(int(b));adj.setdefault(int(b),set()).add(int(a))
        assert all(len(a)==2 for a in adj.values()),f'{name}: vertex link degree'
        todo=[next(iter(adj))];seen=set()
        while todo:
            a=todo.pop()
            if a not in seen:seen.add(a);todo.extend(adj[a]-seen)
        assert len(seen)==len(adj),f'{name}: singular vertex'

for name,m in parts.items():
    m.merge_vertices();m.remove_unreferenced_vertices();verify(m,name)
    p=m.copy();p.apply_translation(-p.bounds[0])
    path=STL/(name+'.stl');p.export(path)
    loaded=trimesh.load_mesh(path,process=True);verify(loaded,name+' STL reload')
    assert np.allclose(loaded.extents,m.extents,atol=.0001)
    assert loaded.bounds[0,2]==0
    report['parts'][name]={'color':colors[name],'bounds_mm':m.bounds.tolist(),
        'print_size_mm':p.extents.tolist(),'assembly_translation_from_stl_mm':m.bounds[0].tolist(),
        'triangles':len(loaded.faces),'watertight':True,'edge_and_vertex_manifold':True,
        'connected_solids':1,'consistent_winding':True,'positive_volume':True,
        'volume_mm3':float(m.volume),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

for i,(a,ma) in enumerate(parts.items()):
    for b,mb in list(parts.items())[i+1:]:
        hit=trimesh.boolean.intersection([ma,mb],engine='manifold')
        volume=0 if hit is None else abs(hit.volume)
        assert volume<.01,(a,b,volume)
        report['intersections_mm3'][a+' + '+b]=float(volume)

def export_3mf(path,objects,material_colors):
    ns='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
    root=Element('model',{'unit':'millimeter','xml:lang':'en-US','xmlns':ns})
    SubElement(root,'metadata',{'name':'Title'}).text='Pixel Devil Fruit — 240 mm reference edition'
    resources=SubElement(root,'resources'); bm=SubElement(resources,'basematerials',{'id':'1'})
    for c in material_colors.values():SubElement(bm,'base',{'name':c,'displaycolor':c+'FF'})
    for i,(name,m) in enumerate(objects.items()):
        obj=SubElement(resources,'object',{'id':str(i+2),'type':'model','name':name,'pid':'1','pindex':str(i)})
        mesh=SubElement(obj,'mesh');vs=SubElement(mesh,'vertices');ts=SubElement(mesh,'triangles')
        for v in m.vertices:SubElement(vs,'vertex',dict(zip(('x','y','z'),(f'{a:.7f}' for a in v))))
        for f in m.faces:SubElement(ts,'triangle',dict(zip(('v1','v2','v3'),map(str,f))))
    # One build item containing four independently colored, aligned components.
    assembly=SubElement(resources,'object',{'id':'100','type':'model','name':'Complete assembly'})
    comps=SubElement(assembly,'components')
    for i in range(len(objects)):SubElement(comps,'component',{'objectid':str(i+2)})
    build=SubElement(root,'build');SubElement(build,'item',{'objectid':'100'})
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        z.writestr('3D/3dmodel.model',tostring(root,encoding='utf-8',xml_declaration=True))

export_3mf(OUT/'Devil_Fruit_240mm_Assembly.3mf',parts,colors)
# Independently round-trip the container using trimesh's 3MF loader.
scene=trimesh.load(OUT/'Devil_Fruit_240mm_Assembly.3mf',force='scene')
assert len(scene.geometry)==4
for name,m in scene.geometry.items():verify(m,'3MF '+name)
expected=np.array([shape.bounds[2]-shape.bounds[0],shape.bounds[3]-shape.bounds[1],9.6])
assert np.allclose(scene.extents,expected,atol=1e-4),(scene.extents,expected)
report['assembly_size_mm']=scene.extents.tolist()
report['3mf_roundtrip']={'geometry_count':4,'units':'millimeter','all_meshes_verified':True,'assembly_bounds_correct':True}
# Geometry for an exact portable viewer / Blender render, preserving assembly positions.
jsonparts={name:{'vertices':m.vertices.tolist(),'faces':m.faces.tolist(),'color':colors[name]} for name,m in parts.items()}
(OUT/'assembly_geometry.json').write_text(json.dumps(jsonparts))
(OUT/'mesh_verification.json').write_text(json.dumps(report,indent=2))
concept()
print(json.dumps(report,indent=2))
