# Dragon + Pixel prototype kit

Open [the project guide](prints/dragon-pixel-shelves/README.md).

Full gallery: https://github.com/gdayoub/george-Print-files

This is an untested prototype with no assigned load rating. The ZIP preserves the project layout and includes instructions, geometry, references, editable source and validation.
